<?php
  require_once('../Controllers/ContactController_2.php');
  $ContactUpdata = new ContactController_2();
  $UpdateData = $ContactUpdata -> UpdateData();
?>