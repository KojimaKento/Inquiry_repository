<div class="row">
    <div class="col-12 px-0">
        <footer class="footer" style="display:flex;">
            <p class="footer-content">プライバシーポリシー</p>
            <p class="footer-content">お問合せ</p>
            <p class="footer-content">運営会社</p>
        </footer>
    </div>
</div>